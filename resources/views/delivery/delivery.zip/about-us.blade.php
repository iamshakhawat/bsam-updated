@extends('delivery.layout.main')
@section('title','About Us')
@section('content')
<div class="container">
    <h1 class="text-center my-5">About Us</h1>
    <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. </h2>
    <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus rerum optio dolores omnis nam commodi, excepturi tempora eaque minima voluptatem dignissimos totam corrupti autem officia quia tenetur, aliquam quibusdam blanditiis. Illum ex cupiditate, ea porro, dolore, cumque voluptas praesentium blanditiis molestias aliquam fugiat at perferendis nemo dignissimos quibusdam minus dolor asperiores adipisci amet culpa iste nihil debitis ratione eligendi! Doloremque odit voluptate animi! Exercitationem quia iure, ullam quod ratione harum est nam eveniet at nisi nihil praesentium debitis sint. Alias, quaerat temporibus accusantium doloremque itaque similique eaque praesentium numquam nam, libero voluptas cum cupiditate, tempora in odio facilis dolorem nisi?</p>


    
    <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. </h2>
    <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus rerum optio dolores omnis nam commodi, excepturi tempora eaque minima voluptatem dignissimos totam corrupti autem officia quia tenetur, aliquam quibusdam blanditiis. Illum ex cupiditate, ea porro, dolore, cumque voluptas praesentium blanditiis molestias aliquam fugiat at perferendis nemo dignissimos quibusdam minus dolor asperiores adipisci amet culpa iste nihil debitis ratione eligendi! Doloremque odit voluptate animi! Exercitationem quia iure, ullam quod ratione harum est nam eveniet at nisi nihil praesentium debitis sint. Alias, quaerat temporibus accusantium doloremque itaque similique eaque praesentium numquam nam, libero voluptas cum cupiditate, tempora in odio facilis dolorem nisi?</p>



    
    <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. </h2>
    <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus rerum optio dolores omnis nam commodi, excepturi tempora eaque minima voluptatem dignissimos totam corrupti autem officia quia tenetur, aliquam quibusdam blanditiis. Illum ex cupiditate, ea porro, dolore, cumque voluptas praesentium blanditiis molestias aliquam fugiat at perferendis nemo dignissimos quibusdam minus dolor asperiores adipisci amet culpa iste nihil debitis ratione eligendi! Doloremque odit voluptate animi! Exercitationem quia iure, ullam quod ratione harum est nam eveniet at nisi nihil praesentium debitis sint. Alias, quaerat temporibus accusantium doloremque itaque similique eaque praesentium numquam nam, libero voluptas cum cupiditate, tempora in odio facilis dolorem nisi?</p>


    
    <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. </h2>
    <p class="mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus rerum optio dolores omnis nam commodi, excepturi tempora eaque minima voluptatem dignissimos totam corrupti autem officia quia tenetur, aliquam quibusdam blanditiis. Illum ex cupiditate, ea porro, dolore, cumque voluptas praesentium blanditiis molestias aliquam fugiat at perferendis nemo dignissimos quibusdam minus dolor asperiores adipisci amet culpa iste nihil debitis ratione eligendi! Doloremque odit voluptate animi! Exercitationem quia iure, ullam quod ratione harum est nam eveniet at nisi nihil praesentium debitis sint. Alias, quaerat temporibus accusantium doloremque itaque similique eaque praesentium numquam nam, libero voluptas cum cupiditate, tempora in odio facilis dolorem nisi?</p>

</div>
@endsection